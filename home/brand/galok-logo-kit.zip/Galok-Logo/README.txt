Galok 标志 / Galok Logo

Original/  获确认的生图原件，保留原始透明度和色彩。
Vector/    可缩放的 SVG、PDF 和 EPS。标准版为钴蓝 #1943BD，另附黑白 SVG。
Raster/    透明 PNG（16–1024 像素）、透明 WebP 和浅底 JPEG；白色标志用于深色背景。
Icons/     浏览器 ICO、自适应明暗 SVG、macOS ICNS、Apple 触屏图标、Android 普通和可裁切图标。

The vector paths follow the two shapes of the approved artwork. The EPS and PDF use RGB color. For print, convert with the profile supplied by the printer.
