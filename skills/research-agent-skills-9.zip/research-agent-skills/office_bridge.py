from pathlib import Path
from shutil import copyfileobj, which
import os
import subprocess
import tempfile

from common import output_file, scoped_path


_OFFICE_SUFFIXES = {".docx", ".xlsx", ".pptx"}


def office_pdf(spec):
    return _convert(spec, _OFFICE_SUFFIXES, ".pdf")


def legacy_xls(spec):
    return _convert(spec, {".xls"}, ".xlsx")


def _convert(spec, input_suffixes, output_suffix):
    source = scoped_path(spec["input"])
    if not source.is_file() or source.suffix.lower() not in input_suffixes:
        raise ValueError("Expected source file type: " + ", ".join(sorted(input_suffixes)))
    cli = os.environ.get("PORTABLE_LIBREOFFICE") or which("soffice.com") or which("soffice")
    if not cli and os.name == "nt":
        candidate = Path(os.environ.get("ProgramFiles", "C:/Program Files")) / "LibreOffice/program/soffice.com"
        if candidate.is_file():
            cli = str(candidate)
    if not cli:
        raise RuntimeError("Install LibreOffice or set PORTABLE_LIBREOFFICE to its headless CLI path.")
    destination = output_file(spec["output"], output_suffix)
    with tempfile.TemporaryDirectory(prefix="portable-office-") as temporary:
        root = Path(temporary)
        profile = (root / "profile").as_uri()
        opts = {"creationflags": subprocess.CREATE_NO_WINDOW} if os.name == "nt" else {}
        process = subprocess.run(
            [cli, f"-env:UserInstallation={profile}", "--headless", "--convert-to", output_suffix[1:], "--outdir", str(root), str(source)],
            capture_output=True, timeout=120, **opts,
        )
        converted = root / (source.stem + output_suffix)
        if process.returncode or not converted.is_file():
            raise RuntimeError(f"LibreOffice did not produce a {output_suffix} file. Check document validity and installed fonts.")
        with converted.open("rb") as input_stream, destination.open("xb") as output_stream:
            copyfileobj(input_stream, output_stream)
    return {"path": str(destination)}
