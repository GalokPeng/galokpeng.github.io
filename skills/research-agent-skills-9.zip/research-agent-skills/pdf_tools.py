from html import escape
from pathlib import Path
from shutil import which
from tempfile import TemporaryDirectory
import os
import re
import subprocess

from common import output_file, scoped_path


def _page_indexes(numbers, total):
    if numbers is None:
        return list(range(total))
    if not numbers or any(type(number) is not int or not 1 <= number <= total for number in numbers):
        raise ValueError(f"PDF page numbers must be between 1 and {total}.")
    return [number - 1 for number in numbers]


def _text_pdf(spec, path):
    from reportlab.lib.enums import TA_LEFT
    from reportlab.lib.pagesizes import A4
    from reportlab.lib.styles import ParagraphStyle
    from reportlab.pdfbase import pdfmetrics
    from reportlab.pdfbase.cidfonts import UnicodeCIDFont
    from reportlab.pdfbase.ttfonts import TTFont
    from reportlab.platypus import Paragraph, SimpleDocTemplate, Spacer

    texts = [spec["title"], *spec.get("paragraphs", [])]
    if "font" in spec:
        name = "EmbeddedDocumentFont"
        pdfmetrics.registerFont(TTFont(name, str(scoped_path(spec["font"]))))
    elif any(not text.isascii() for text in texts):
        name = "STSong-Light"
        pdfmetrics.registerFont(UnicodeCIDFont(name))
    else:
        name = "Helvetica"
    title = ParagraphStyle("Title", fontName=name, fontSize=21, leading=28, wordWrap="CJK")
    body = ParagraphStyle("Body", fontName=name, fontSize=11, leading=17, alignment=TA_LEFT, wordWrap="CJK")
    linear = []
    for index, text in enumerate(texts):
        linear.append(Paragraph(escape(text).replace("\n", "<br/>"), title if index == 0 else body))
        linear.append(Spacer(1, 12))
    with path.open("xb") as destination:
        SimpleDocTemplate(destination, pagesize=A4, title=spec["title"], topMargin=52, bottomMargin=52).build(linear)


def _render(spec, path):
    import pypdfium2 as pdfium

    scale = spec.get("scale", 1.5)
    if not 0.25 <= scale <= 5:
        raise ValueError("Render scale must be between 0.25 and 5.")
    source = scoped_path(spec["input"])
    document = pdfium.PdfDocument(source)
    try:
        index = _page_indexes([spec.get("page", 1)], len(document))[0]
        page = document[index]
        try:
            bitmap = page.render(scale=scale)
            try:
                image = bitmap.to_pil()
                with path.open("xb") as stream:
                    image.save(stream, format="PNG")
                return list(image.size)
            finally:
                bitmap.close()
        finally:
            page.close()
    finally:
        document.close()


def _write_pdf(writer, path):
    with path.open("xb") as destination:
        writer.write(destination)
    return {"path": str(path), "pages": len(writer.pages)}


def _ocr(spec, indexes):
    binary = os.environ.get("PORTABLE_TESSERACT") or which("tesseract")
    if not binary:
        raise RuntimeError("Install Tesseract and its language files or set PORTABLE_TESSERACT.")
    language = spec.get("language", "eng")
    if not re.fullmatch(r"[a-zA-Z0-9_]+(?:\+[a-zA-Z0-9_]+)*", language):
        raise ValueError("Use Tesseract language codes such as eng or eng+chi_sim.")
    result = []
    options = {"creationflags": subprocess.CREATE_NO_WINDOW} if os.name == "nt" else {}
    with TemporaryDirectory(prefix="portable-pdf-ocr-") as temporary:
        for index in indexes:
            image = Path(temporary) / f"page-{index + 1}.png"
            _render({"input": spec["input"], "page": index + 1, "scale": spec.get("scale", 3)}, image)
            response = subprocess.run(
                [binary, str(image), "stdout", "-l", language],
                capture_output=True, timeout=120, **options,
            )
            if response.returncode:
                raise RuntimeError(f"Tesseract failed for page {index + 1}. Check the language files and page quality.")
            result.append({"page": index + 1, "text": response.stdout.decode("utf-8")})
    return {"selected": result}


def pdf(spec):
    from pypdf import PdfReader, PdfWriter

    action = spec["action"]
    if action == "create":
        path = output_file(spec["output"], ".pdf")
        _text_pdf(spec, path)
        reader = PdfReader(path)
        try:
            return {"path": str(path), "pages": len(reader.pages)}
        finally:
            reader.close()
    if action == "render":
        path = output_file(spec["output"], ".png")
        return {"path": str(path), "size": _render(spec, path)}
    if action == "merge":
        writer = PdfWriter()
        if not spec["inputs"]:
            raise ValueError("Provide at least one PDF to merge.")
        try:
            for item in spec["inputs"]:
                writer.append(scoped_path(item))
            return _write_pdf(writer, output_file(spec["output"], ".pdf"))
        finally:
            writer.close()

    reader = PdfReader(scoped_path(spec["input"]))
    try:
        if action == "ocr":
            return _ocr(spec, _page_indexes(spec.get("pages", [1]), len(reader.pages)))
        if action == "inspect":
            fields = {
                key: {"type": str(data.get("/FT", "")), "value": str(data.get("/V", ""))}
                for key, data in (reader.get_fields() or {}).items()
            }
            indexes = _page_indexes(spec.get("pages", list(range(1, min(3, len(reader.pages)) + 1)) or None), len(reader.pages))
            return {
                "pages": len(reader.pages), "fields": fields,
                "selected": [{"page": index + 1, "text": reader.pages[index].extract_text()} for index in indexes],
            }
        writer = PdfWriter()
        try:
            if action == "select":
                writer.append(reader, pages=_page_indexes(spec["pages"], len(reader.pages)))
            elif action == "fill":
                fields = reader.get_fields() or {}
                updates = spec["fields"]
                if not updates or any(key not in fields for key in updates):
                    raise ValueError("Provide field names reported by PDF inspect.")
                writer.append(reader)
                writer.update_page_form_field_values(None, updates, auto_regenerate=False)
            else:
                raise ValueError("PDF actions are create, inspect, render, merge, select, fill and ocr.")
            return _write_pdf(writer, output_file(spec["output"], ".pdf"))
        finally:
            writer.close()
    finally:
        reader.close()
