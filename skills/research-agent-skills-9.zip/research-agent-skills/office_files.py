from copy import deepcopy
from datetime import datetime, timezone
import csv
import re

from common import output_file, scoped_path


def _save_new(document, path):
    with path.open("xb") as destination:
        document.save(destination)
    return str(path)


def _word_paragraphs(container):
    yield from container.paragraphs
    cells_seen = set()
    for table in container.tables:
        for row in table.rows:
            for cell in row.cells:
                if cell._tc not in cells_seen:
                    cells_seen.add(cell._tc)
                    yield from _word_paragraphs(cell)


def _word_groups(paragraph):
    from docx.oxml.ns import qn
    from docx.text.run import Run

    group = []
    for node in paragraph._p:
        if node.tag == qn("w:r") and all(child.tag in {qn("w:rPr"), qn("w:t")} for child in node):
            run = Run(node, paragraph)
            if run.text:
                group.append(run)
                continue
        if group:
            yield group
            group = []
    if group:
        yield group


def _word_run(paragraph, style, text):
    from docx.oxml import OxmlElement
    from docx.text.run import Run

    node = OxmlElement("w:r")
    if style is not None:
        node.append(deepcopy(style))
    run = Run(node, paragraph)
    run.text = text
    return node


def _word_slice(paragraph, runs, start, end):
    nodes = []
    index = 0
    for run in runs:
        content = run.text
        left = max(start - index, 0)
        right = min(end - index, len(content))
        if left < right:
            nodes.append(_word_run(paragraph, run._r.rPr, content[left:right]))
        index += len(content)
    return nodes


def _revision_node(kind, nodes, identity, author):
    from docx.oxml import OxmlElement
    from docx.oxml.ns import qn

    node = OxmlElement("w:" + kind)
    for attr, value in {
        "id": str(next(identity)), "author": author,
        "date": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
    }.items():
        node.set(qn("w:" + attr), value)
    if kind == "del":
        for run in nodes:
            for literal in run.findall(qn("w:t")):
                literal.tag = qn("w:delText")
    node.extend(nodes)
    return node


def _install_word_nodes(group, nodes):
    pivot = group[0]._r
    for node in nodes:
        pivot.addprevious(node)
    for run in group:
        run._r.getparent().remove(run._r)


def _word_review(document, spec):
    from docx.oxml.ns import qn
    from docx.text.run import Run
    from itertools import count

    search = spec["find"]
    if not search:
        raise ValueError("Provide a nonempty exact match.")
    author = spec.get("author", "Reviewer")
    old_ids = [
        int(value) for node in document._element.xpath(".//w:ins | .//w:del")
        if (value := node.get(qn("w:id"))) and value.isdecimal()
    ]
    identities = count(max(old_ids, default=-1) + 1)
    action = spec["action"]
    occurrence = spec.get("occurrence", 1)
    if not isinstance(occurrence, int) or occurrence < 1:
        raise ValueError("occurrence must be a positive 1-based index.")
    replacement = spec.get("replace", "")
    if action == "track" and any(c in replacement for c in "\r\n\t"):
        raise ValueError("Tracked replacement is within a paragraph and uses plain text.")
    seen = 0
    changes = 0
    for paragraph in _word_paragraphs(document):
        for group in list(_word_groups(paragraph)):
            content = "".join(run.text for run in group)
            matches = list(re.finditer(re.escape(search), content))
            if not matches:
                continue
            nodes, end = [], 0
            for item in matches:
                seen += 1
                if action == "comment" and seen != occurrence:
                    continue
                nodes.extend(_word_slice(paragraph, group, end, item.start()))
                selected = _word_slice(paragraph, group, *item.span())
                end = item.end()
                if action == "comment":
                    nodes.extend(selected)
                    nodes.extend(_word_slice(paragraph, group, end, len(content)))
                    _install_word_nodes(group, nodes)
                    initials = spec.get("initials", "")
                    document.add_comment([Run(node, paragraph) for node in selected], spec["text"], author, initials)
                    return 1
                style = selected[0].rPr
                inserted = [_word_run(paragraph, style, replacement)] if replacement else []
                if action == "track":
                    nodes.append(_revision_node("del", selected, identities, author))
                    if inserted:
                        nodes.append(_revision_node("ins", inserted, identities, author))
                else:
                    nodes.extend(inserted)
                changes += 1
            if end:
                nodes.extend(_word_slice(paragraph, group, end, len(content)))
                _install_word_nodes(group, nodes)
    if not changes:
        raise ValueError("Match was not found in plain body text or tables.")
    return changes


def word(spec):
    from docx import Document

    action = spec["action"]
    if action == "create":
        doc = Document()
        doc.add_heading(spec["title"], 0)
        for block in spec.get("blocks", []):
            kind = block["type"]
            if kind == "paragraph":
                doc.add_paragraph(block["text"])
            elif kind == "heading":
                doc.add_heading(block["text"], level=block.get("level", 1))
            elif kind == "bullet":
                doc.add_paragraph(block["text"], style="List Bullet")
            elif kind == "table":
                rows = block["rows"]
                if not rows or not rows[0] or any(len(row) != len(rows[0]) for row in rows):
                    raise ValueError("Provide a nonempty rectangular table.")
                table = doc.add_table(rows=len(rows), cols=len(rows[0]), style="Table Grid")
                for index, row in enumerate(rows):
                    for column, value in enumerate(row):
                        table.cell(index, column).text = str(value)
            else:
                raise ValueError(f"Unknown Word block {kind}.")
        return {"path": _save_new(doc, output_file(spec["output"], ".docx"))}

    doc = Document(scoped_path(spec["input"]))
    if action == "inspect":
        return {
            "paragraphs": [p.text for p in _word_paragraphs(doc)],
            "comments": [{"author": comment.author, "text": comment.text} for comment in doc.comments],
            "insertions": len(doc._element.xpath(".//w:ins")),
            "deletions": len(doc._element.xpath(".//w:del")),
        }
    if action not in {"replace", "track", "comment"}:
        raise ValueError("Word actions are create, inspect, replace, track and comment.")
    changes = _word_review(doc, spec)
    return {"path": _save_new(doc, output_file(spec["output"], ".docx")), "changes": changes}


def presentation(spec):
    from pptx import Presentation
    from pptx.chart.data import CategoryChartData
    from pptx.enum.chart import XL_CHART_TYPE
    from pptx.util import Inches

    action = spec["action"]
    if action == "create":
        deck = Presentation(scoped_path(spec["template"])) if "template" in spec else Presentation()
        for item in spec["slides"]:
            slide = deck.slides.add_slide(deck.slide_layouts[item.get("layout", 1)])
            title = slide.shapes.title
            if title is None:
                raise ValueError("Choose a layout with a title placeholder.")
            title.text = item["title"]
            bullets = item.get("bullets", [])
            if bullets:
                text_shape = next(
                    (shape for shape in slide.placeholders if shape.has_text_frame
                     and shape._element is not title._element), None,
                )
                if text_shape is None:
                    raise ValueError("Choose a layout with a text placeholder for bullets.")
                body = text_shape.text_frame
                for i, text in enumerate(bullets):
                    paragraph = body.paragraphs[0] if i == 0 else body.add_paragraph()
                    paragraph.text = text
            if "chart" in item:
                chart = item["chart"]
                data = CategoryChartData()
                data.categories = chart["categories"]
                for series in chart["series"]:
                    if len(series["values"]) != len(chart["categories"]):
                        raise ValueError("Chart series values must match category count.")
                    data.add_series(series["name"], series["values"])
                style = {"line": XL_CHART_TYPE.LINE, "bar": XL_CHART_TYPE.COLUMN_CLUSTERED}[chart["kind"]]
                if bullets:
                    # Keep the bullets and chart in separate regions.
                    text_shape.width = Inches(3.3)
                    left, width = 4.1, 5.2
                else:
                    left, width = 0.8, 8.5
                slide.shapes.add_chart(style, Inches(left), Inches(1.65), Inches(width), Inches(4.6), data)
            if "notes" in item:
                slide.notes_slide.notes_text_frame.text = item["notes"]
        return {"path": _save_new(deck, output_file(spec["output"], ".pptx")), "slides": len(deck.slides)}

    deck = Presentation(scoped_path(spec["input"]))
    if action == "inspect":
        return {"slides": [
            {"title": slide.shapes.title.text if slide.shapes.title else "",
             "text": [shape.text for shape in slide.shapes if shape.has_text_frame],
             "charts": sum(shape.has_chart for shape in slide.shapes),
             "notes": slide.notes_slide.notes_text_frame.text if slide.has_notes_slide else ""}
            for slide in deck.slides
        ]}
    if action != "replace" or not spec["find"]:
        raise ValueError("Presentation actions are create, inspect and replace. Replacement uses exact text.")
    changes = 0
    for slide in deck.slides:
        for shape in slide.shapes:
            if shape.has_text_frame:
                for paragraph in shape.text_frame.paragraphs:
                    changes += _replace_presentation_runs(paragraph.runs, spec["find"], spec["replace"])
    if not changes:
        raise ValueError("Match was not found in slide text.")
    return {"path": _save_new(deck, output_file(spec["output"], ".pptx")), "changes": changes}


def _replace_presentation_runs(runs, search, replacement):
    text = "".join(run.text for run in runs)
    matches = list(re.finditer(re.escape(search), text))
    starts = [0]
    for run in runs:
        starts.append(starts[-1] + len(run.text))
    for match in reversed(matches):
        start, end = match.span()
        inserted = False
        for i, run in enumerate(runs):
            if starts[i] < end and starts[i + 1] > start:
                lo = max(start - starts[i], 0)
                hi = min(end - starts[i], starts[i + 1] - starts[i])
                run.text = run.text[:lo] + (replacement if not inserted else "") + run.text[hi:]
                inserted = True
    return len(matches)


def _sheet_write(sheet, start, rows):
    from openpyxl.utils.cell import coordinate_to_tuple

    if not rows or not rows[0] or any(not isinstance(row, list) or len(row) != len(rows[0]) for row in rows):
        raise ValueError("Provide a nonempty rectangular rows array.")
    row_index, column_index = coordinate_to_tuple(start)
    if row_index < 1 or column_index < 1 or row_index + len(rows) - 1 > 1048576 or column_index + len(rows[0]) - 1 > 16384:
        raise ValueError("Rows fall outside Excel worksheet bounds.")
    for i, row in enumerate(rows):
        for j, value in enumerate(row):
            sheet.cell(row_index + i, column_index + j).value = value


def _sheet_settings(sheet, settings):
    from openpyxl.chart import BarChart, LineChart, Reference
    from openpyxl.styles import Font, PatternFill
    from openpyxl.utils.cell import range_boundaries

    if settings.get("header"):
        for cell in sheet[1]:
            cell.font = Font(bold=True, color="FFFFFF")
            cell.fill = PatternFill("solid", fgColor="174F55")
    if "freeze" in settings:
        sheet.freeze_panes = settings["freeze"]
    for column, width in settings.get("widths", {}).items():
        sheet.column_dimensions[column].width = width
    for item in settings.get("charts", []):
        min_col, min_row, max_col, max_row = range_boundaries(item["range"])
        if min_col == max_col or min_row == max_row:
            raise ValueError("Chart range starts with a header row and includes category and data columns.")
        chart = {"line": LineChart, "bar": BarChart}[item["kind"]]()
        chart.title = item.get("title", "")
        chart.add_data(Reference(sheet, min_col=min_col + 1, max_col=max_col, min_row=min_row, max_row=max_row), titles_from_data=True)
        chart.set_categories(Reference(sheet, min_col=min_col, min_row=min_row + 1, max_row=max_row))
        sheet.add_chart(chart, item["anchor"])


def spreadsheet(spec):
    from openpyxl import Workbook, load_workbook

    action = spec["action"]
    if action == "convert_legacy":
        from office_bridge import legacy_xls

        return legacy_xls(spec)
    if action == "import_delimited":
        source = scoped_path(spec["input"])
        delimiter = {".csv": ",", ".tsv": "\t"}.get(source.suffix.lower())
        if delimiter is None:
            raise ValueError("Select a CSV or TSV input file.")
        book = Workbook()
        target = book.active
        target.title = spec.get("sheet", "Data")
        with source.open(encoding="utf-8-sig", newline="") as stream:
            for row in csv.reader(stream, delimiter=delimiter):
                target.append(row)
                for cell in target[target.max_row] if row else ():
                    if isinstance(cell.value, str):
                        cell.data_type = "s"
        return {"path": _save_new(book, output_file(spec["output"], ".xlsx")), "sheet": target.title}
    if action == "create":
        book = Workbook()
        sheets = spec["sheets"]
        if not sheets:
            raise ValueError("Provide at least one sheet.")
        book.remove(book.active)
        for item in sheets:
            sheet = book.create_sheet(item["name"])
            if item.get("rows"):
                _sheet_write(sheet, "A1", item["rows"])
            _sheet_settings(sheet, item)
        return {"path": _save_new(book, output_file(spec["output"], ".xlsx")), "sheets": book.sheetnames}
    input_path = scoped_path(spec["input"])
    if input_path.suffix.lower() != ".xlsx":
        raise ValueError("Use XLSX for standalone spreadsheet editing.")
    book = load_workbook(input_path, data_only=action == "inspect" and spec.get("cached_values", False))
    try:
        if action == "inspect" and "sheet" not in spec:
            return {"sheets": [{"name": sheet.title, "used_range": sheet.calculate_dimension()} for sheet in book.worksheets]}
        target = book[spec["sheet"]]
        if action == "export_delimited":
            suffix = scoped_path(spec["output"]).suffix.lower()
            delimiter = {".csv": ",", ".tsv": "\t"}.get(suffix)
            if delimiter is None:
                raise ValueError("Choose a CSV or TSV output path.")
            path = output_file(spec["output"], suffix)
            with path.open("x", encoding="utf-8-sig", newline="") as stream:
                csv.writer(stream, delimiter=delimiter).writerows(target.values)
            return {"path": str(path), "sheet": target.title}
        if action == "inspect":
            from openpyxl.utils.cell import range_boundaries
            region = spec.get("range", "A1:J20")
            c0, r0, c1, r1 = range_boundaries(region)
            if None in (c0, r0, c1, r1) or (c1-c0+1)*(r1-r0+1) > 5000:
                raise ValueError("Select a bounded worksheet range of 5,000 cells or fewer.")
            values = target.iter_rows(min_row=r0, max_row=r1, min_col=c0, max_col=c1, values_only=True)
            return {"sheet": target.title, "range": region, "rows": [
                [cell.isoformat() if hasattr(cell, "isoformat") else cell for cell in row] for row in values
            ]}
        if action != "write":
            raise ValueError("Spreadsheet actions are create, inspect and write.")
        _sheet_write(target, spec["start"], spec["rows"])
        _sheet_settings(target, spec)
        return {"path": _save_new(book, output_file(spec["output"], ".xlsx")), "sheet": target.title}
    finally:
        book.close()
