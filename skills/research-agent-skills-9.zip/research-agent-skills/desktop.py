import ctypes
import io
import re
import sys
import threading


def _load_windows():
    if sys.platform != "win32":
        raise RuntimeError("Desktop tools require an interactive Windows session.")
    ctypes.windll.user32.SetProcessDpiAwarenessContext(ctypes.c_void_p(-4))
    import win32gui
    from pywinauto import Desktop, keyboard, mouse

    return win32gui, Desktop, keyboard, mouse


def _details(gui, hwnd):
    return {
        "hwnd": hwnd,
        "title": gui.GetWindowText(hwnd),
        "class_name": gui.GetClassName(hwnd),
        "rect": list(gui.GetWindowRect(hwnd)),
        "minimized": bool(gui.IsIconic(hwnd)),
    }


def windows(title_contains=""):
    gui, _, _, _ = _load_windows()
    found = []

    def collect(hwnd, _):
        if gui.IsWindowVisible(hwnd):
            item = _details(gui, hwnd)
            if item["title"] and title_contains.casefold() in item["title"].casefold():
                found.append(item)
        return True

    gui.EnumWindows(collect, None)
    return found


def _target(gui, hwnd):
    if not gui.IsWindow(hwnd) or not gui.IsWindowVisible(hwnd) or gui.GetAncestor(hwnd, 2) != hwnd:
        raise ValueError("Select a current top-level window handle from desktop_windows.")
    if gui.IsIconic(hwnd):
        raise ValueError("Restore the window before interacting with it.")
    return _details(gui, hwnd)


def tree(hwnd, depth=3, limit=100):
    gui, desktop, _, _ = _load_windows()
    target = _target(gui, hwnd)
    if not 0 <= depth <= 8 or not 1 <= limit <= 300:
        raise ValueError("Use depth 0–8 and limit 1–300.")

    def visit(control, level, remaining):
        element = control.element_info
        rect = element.rectangle
        result = {
            "name": element.name,
            "type": element.control_type,
            "automation_id": element.automation_id,
            "rect": [rect.left, rect.top, rect.right, rect.bottom],
        }
        remaining[0] -= 1
        if level < depth:
            children = []
            for child in control.children():
                if remaining[0] == 0:
                    break
                children.append(visit(child, level + 1, remaining))
            if children:
                result["children"] = children
        return result

    root = desktop(backend="uia").window(handle=hwnd).wrapper_object()
    return {"window": target, "tree": visit(root, 0, [limit])}


def _graphics_image(hwnd):
    from PIL import Image
    try:
        from windows_capture import WindowsCapture
    except ImportError:
        raise RuntimeError("Install windows-capture 2.x to use Windows Graphics Capture.") from None

    capture_api = WindowsCapture(window_hwnd=hwnd, cursor_capture=False)
    ready = threading.Event()
    output = []
    errors = []

    @capture_api.event
    def on_frame_arrived(frame, control):
        try:
            output.append(Image.fromarray(frame.frame_buffer[:, :, [2, 1, 0]]))
        except Exception as error:
            errors.append(error)
        finally:
            control.stop()
            ready.set()

    @capture_api.event
    def on_closed():
        ready.set()

    stream = capture_api.start_free_threaded()
    if not ready.wait(timeout=6):
        stream.stop()
    stream.wait()
    if not output:
        raise RuntimeError("No frame was available from Windows Graphics Capture.") from (errors[0] if errors else None)
    return output[0]


def _frame_offset(target, image):
    from ctypes.wintypes import RECT

    left, top, right, bottom = target["rect"]
    geometry = RECT()
    extended_bounds = 9
    status = ctypes.windll.dwmapi.DwmGetWindowAttribute(
        ctypes.c_void_p(target["hwnd"]), extended_bounds, ctypes.byref(geometry), ctypes.sizeof(geometry),
    )
    if not status and image.size == (geometry.right - geometry.left, geometry.bottom - geometry.top):
        return [geometry.left - left, geometry.top - top]
    if image.size == (right - left, bottom - top):
        return [0, 0]
    return None


def capture(hwnd, mode="gdi"):
    gui, _, _, _ = _load_windows()
    from PIL import ImageGrab

    target = _target(gui, hwnd)
    if mode == "gdi":
        image = ImageGrab.grab(window=hwnd)
    elif mode == "graphics":
        image = _graphics_image(hwnd)
    else:
        raise ValueError("Capture mode must be gdi or graphics.")
    data = io.BytesIO()
    image.save(data, format="PNG")
    target["size"] = list(image.size)
    target["capture_mode"] = mode
    target["click_offset"] = [0, 0] if mode == "gdi" else _frame_offset(target, image)
    return target, data.getvalue()


def _focus(gui, desktop, hwnd):
    target = _target(gui, hwnd)
    if gui.GetForegroundWindow() != hwnd:
        desktop(backend="win32").window(handle=hwnd).wrapper_object().set_focus()
    if gui.GetForegroundWindow() != hwnd:
        raise RuntimeError("Windows did not give the target foreground focus.")
    return target


def click(hwnd, x, y, button="left"):
    gui, desktop, _, mouse = _load_windows()
    left, top, right, bottom = _target(gui, hwnd)["rect"]
    if button not in {"left", "right", "middle"} or not (0 <= x < right - left and 0 <= y < bottom - top):
        raise ValueError("Choose a supported mouse button and coordinates within the window.")
    left, top, right, bottom = _focus(gui, desktop, hwnd)["rect"]
    point = (left + x, top + y)
    under_cursor = gui.WindowFromPoint(point)
    if gui.GetAncestor(under_cursor, 2) != hwnd or gui.GetForegroundWindow() != hwnd:
        raise RuntimeError("The click point is covered or outside the active target.")
    mouse.click(button=button, coords=point)
    return {"hwnd": hwnd, "x": x, "y": y, "button": button}


_MODIFIERS = {"CTRL": "^", "ALT": "%", "SHIFT": "+"}
_KEYS = {
    "ESC": "ESC", "ENTER": "ENTER", "TAB": "TAB", "SPACE": "SPACE",
    "BACKSPACE": "BACKSPACE", "DELETE": "DELETE", "INSERT": "INSERT",
    "HOME": "HOME", "END": "END", "PGUP": "PGUP", "PGDN": "PGDN",
    "LEFT": "LEFT", "RIGHT": "RIGHT", "UP": "UP", "DOWN": "DOWN",
    **{f"F{number}": f"F{number}" for number in range(1, 25)},
}


def _key_sequence(shortcut):
    *modifiers, key = [part.strip().upper() for part in shortcut.split("+")]
    if any(item not in _MODIFIERS for item in modifiers) or len(set(modifiers)) != len(modifiers):
        raise ValueError("Use Ctrl, Alt or Shift before the final key.")
    if re.fullmatch(r"[A-Z0-9]", key):
        encoded = key.lower()
    elif key in _KEYS:
        encoded = "{" + _KEYS[key] + "}"
    else:
        raise ValueError("Use a letter, digit, function key or named navigation key.")
    return "".join(_MODIFIERS[item] for item in modifiers) + encoded


def keys(hwnd, shortcut):
    sequence = _key_sequence(shortcut)
    gui, desktop, keyboard, _ = _load_windows()
    _focus(gui, desktop, hwnd)
    keyboard.send_keys(sequence, vk_packet=False, pause=0)
    return {"hwnd": hwnd, "shortcut": shortcut}


def text(hwnd, value):
    if not 1 <= len(value) <= 1500:
        raise ValueError("Enter 1–1500 characters at a time.")
    gui, desktop, keyboard, _ = _load_windows()
    value = value.replace("\r\n", "\n").replace("\r", "\n")
    _focus(gui, desktop, hwnd)
    for character in value:
        if gui.GetForegroundWindow() != hwnd:
            raise RuntimeError("Focus changed during text entry.")
        if character in "\n\t":
            keyboard.send_keys("{ENTER}" if character == "\n" else "{TAB}", pause=0)
        else:
            units = character.encode("utf-16-le")
            for offset in range(0, len(units), 2):
                unit = int.from_bytes(units[offset:offset + 2], "little")
                keyboard.KeyAction(chr(unit)).run()
    return {"hwnd": hwnd, "characters": len(value)}
