import threading
from typing import Any, Literal

from mcp.server.fastmcp import FastMCP, Image
from mcp.types import CallToolResult, TextContent

import desktop
import excel_live
import google_bridge
import image_api
import office_bridge
import office_files
import pdf_tools
import templates
import visuals


server = FastMCP("research-agent-skills")
_desktop_lock = threading.Lock()
_excel_lock = threading.Lock()
_CHART_RESOURCE = "ui://research-agent-skills/chart.html"


@server.tool()
def desktop_windows(title_contains: str = "") -> list[dict[str, Any]]:
    """List visible Windows desktop windows with HWND, title and screen rectangle."""
    with _desktop_lock:
        return desktop.windows(title_contains)


@server.tool()
def desktop_tree(hwnd: int, depth: int = 3, limit: int = 100) -> dict[str, Any]:
    """Read the Windows UI Automation tree and screen rectangles for a listed HWND."""
    with _desktop_lock:
        return desktop.tree(hwnd, depth, limit)


@server.tool()
def desktop_capture(hwnd: int, mode: Literal["gdi", "graphics"] = "gdi") -> CallToolResult:
    """Return a selected window PNG with optional Windows Graphics Capture and coordinate offsets."""
    with _desktop_lock:
        geometry, data = desktop.capture(hwnd, mode)
    return CallToolResult(content=[Image(data=data, format="png").to_image_content()], structuredContent=geometry)


@server.tool()
def desktop_click(hwnd: int, x: int, y: int, button: Literal["left", "right", "middle"] = "left") -> dict[str, Any]:
    """Focus the selected window and click in physical pixels relative to its upper-left corner."""
    with _desktop_lock:
        return desktop.click(hwnd, x, y, button)


@server.tool()
def desktop_keys(hwnd: int, shortcut: str) -> dict[str, Any]:
    """Send one keyboard combination such as Ctrl+Shift+S, Enter, or Left to the selected window."""
    with _desktop_lock:
        return desktop.keys(hwnd, shortcut)


@server.tool()
def desktop_text(hwnd: int, value: str) -> dict[str, Any]:
    """Type text into the current field of a selected foreground Windows window."""
    with _desktop_lock:
        return desktop.text(hwnd, value)


@server.tool()
def visualize_build(spec: dict[str, Any], output: str) -> dict[str, Any]:
    """Generate standalone interactive HTML. Kinds are line, bar, scatter, simulation and map."""
    return visuals.build(spec, output)


@server.resource(_CHART_RESOURCE, mime_type="text/html;profile=mcp-app")
def visualize_resource() -> str:
    """Load the offline Plotly UI for compatible MCP Apps hosts."""
    return visuals.app_html()


@server.tool(meta={"ui": {"resourceUri": _CHART_RESOURCE}})
def visualize_inline(spec: dict[str, Any]) -> CallToolResult:
    """Display a chart, map or simulation directly in a compatible MCP Apps client."""
    figure = visuals.inline(spec)
    return CallToolResult(
        content=[TextContent(type="text", text=f"Interactive {spec['kind']}: {spec['title']}")],
        structuredContent=figure,
    )


@server.tool()
def template_create(spec: dict[str, Any], output_parent: str) -> dict[str, Any]:
    """Create a reusable SKILL.md and bundle its file, Google Workspace, Slack, site or image reference."""
    return templates.create(spec, output_parent)


@server.tool()
def template_render(skill_dir: str, values: dict[str, str], output: str) -> dict[str, Any]:
    """Fill named {{slots}} in a TXT, Markdown or HTML reference and write a new file."""
    return templates.render(skill_dir, values, output)


@server.tool()
def template_catalog(output_parent: str) -> dict[str, Any]:
    """List templates created under a local catalog directory."""
    return templates.catalog(output_parent)


@server.tool()
def template_revise(spec: dict[str, Any], output_parent: str) -> dict[str, Any]:
    """Create a new version of a local template with selected plan or source changes."""
    return templates.revise(spec, output_parent)


@server.tool()
def word_document(spec: dict[str, Any]) -> dict[str, Any]:
    """Create, inspect, replace text, add a comment or make a tracked edit in DOCX."""
    return office_files.word(spec)


@server.tool()
def pdf_document(spec: dict[str, Any]) -> dict[str, Any]:
    """Create, inspect, render, merge, select pages or fill an AcroForm PDF."""
    return pdf_tools.pdf(spec)


@server.tool()
def powerpoint(spec: dict[str, Any]) -> dict[str, Any]:
    """Create presentations with charts or notes, inspect slides or edit existing slide text."""
    return office_files.presentation(spec)


@server.tool()
def spreadsheet_workbook(spec: dict[str, Any]) -> dict[str, Any]:
    """Create, inspect or edit XLSX files with formulas, formatting and charts."""
    return office_files.spreadsheet(spec)


@server.tool()
def live_excel(spec: dict[str, Any]) -> dict[str, Any]:
    """List open Windows Excel workbooks, read, write, format, chart, calculate, export PDF or save an exact target."""
    with _excel_lock:
        return excel_live.excel_live(spec)


@server.tool()
def image_generate_edit(spec: dict[str, Any]) -> dict[str, Any]:
    """Generate or edit a PNG through the OpenAI Images API with the user's configured key."""
    return image_api.image(spec)


@server.tool()
def office_export_pdf(spec: dict[str, Any]) -> dict[str, Any]:
    """Render DOCX, XLSX or PPTX to PDF with a local LibreOffice installation."""
    return office_bridge.office_pdf(spec)


@server.tool()
def google_workspace(spec: dict[str, Any]) -> dict[str, Any]:
    """Export, import or apply native batchUpdate requests with the authorized Google Workspace APIs."""
    return google_bridge.google_workspace(spec)


if __name__ == "__main__":
    server.run(transport="stdio")
