const status = document.getElementById("status");
const plot = document.getElementById("plot");
let ready = false;

function post(message) {
  window.parent.postMessage({ jsonrpc: "2.0", ...message }, "*");
}

window.addEventListener("message", async (event) => {
  if (event.source !== window.parent || event.data?.jsonrpc !== "2.0") return;
  const message = event.data;
  if (message.id === "portable-init" && message.result) {
    ready = true;
    post({ method: "ui/notifications/initialized" });
    return;
  }
  if (message.method === "ui/resource-teardown" && message.id !== undefined) {
    Plotly.purge(plot);
    post({ id: message.id, result: {} });
    return;
  }
  if (!ready || message.method !== "ui/notifications/tool-result") return;
  const figure = message.params?.structuredContent;
  if (!figure?.data) {
    status.textContent = "The chart tool did not return a figure.";
    return;
  }
  document.getElementById("title").textContent = figure.title;
  try {
    await Plotly.react(plot, figure.data, figure.layout, { responsive: true, displaylogo: false, scrollZoom: true });
    status.hidden = true;
    post({
      method: "ui/notifications/size-changed",
      params: { height: Math.ceil(document.body.getBoundingClientRect().height + 24) },
    });
  } catch {
    status.hidden = false;
    status.textContent = "The returned chart could not be rendered.";
  }
});

if (window.parent === window) {
  status.textContent = "Open this resource through a compatible MCP Apps client.";
} else {
  post({
    id: "portable-init",
    method: "ui/initialize",
    params: { appInfo: { name: "Portable Visualize", version: "1.0.0" }, appCapabilities: {}, protocolVersion: "2026-01-26" },
  });
}
