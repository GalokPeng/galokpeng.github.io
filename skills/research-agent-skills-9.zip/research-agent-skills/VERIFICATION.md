# 验证范围

| 路径 | 验证方式 |
| --- | --- |
| Word | 创建、跨格式文字替换、批注和修订。实际 Microsoft Word 打开测试文件并识别原生批注和修订。 |
| PDF | 实际生成并重新读取 PDF，渲染 PNG，演示合并、选页和填写 AcroForm。Tesseract 的命令对接用模拟进程验证，输入页面由 PDFium 实际渲染。 |
| PPTX、XLSX、TSV | 重新打开输出文件，验证图表、备注、公式、格式、数据写入和 TSV 往返。LibreOffice 则用模拟进程验证参数和输出交接。 |
| 实时 Excel | 在独立隐藏的 Microsoft Excel 实例里使用临时工作簿，验证读取、写入、重算、格式、图表、保存和 PDF 导出。这次测试通过 COM 操作该实例。同一桌面上不同登录身份或多个 Excel 实例可能影响 attach。 |
| Windows 操作 | 测试窗口的发现、控件树和 PNG 格式已验证。快捷键、鼠标和中文及补充字符输入验证到模拟派发层。Graphics Capture 捕获了测试窗口的图像缓冲，完全离屏的测试窗口返回全黑像素。 |
| 可视化 | 独立 HTML 在离线 Edge 中验证图表、地图悬浮和场景滑块。独立 MCP 客户端发现工具和资源，模拟 MCP Apps 宿主在浏览器中完成内嵌握手并改变滑块结果。 |
| 模板 | 创建、填写、目录发现和新版本生成已验证。Google 和 Slack 的外部请求按模拟响应验证。 |
| ImageGen 与 Google Workspace | 用真实 SDK 的模拟 HTTP 请求验证图像生成与 multipart 编辑，通过模拟 API 验证 Google 导出、导入与原生更新。真实服务需用户自己的凭据和权限。 |

`examples/` 提供可复用的输入和一个可离线打开的滑块示例。`COMMANDS.md` 列出接口、参数和额外依赖。套件在 Windows 验证，macOS 和 Linux 上可先从非桌面命令开始验证。
