from urllib.error import HTTPError, URLError
from urllib.parse import urlencode, urlsplit
from urllib.request import HTTPSHandler, Request, build_opener
from uuid import uuid4
import json
import re
import ssl

from common import output_file, scoped_path
from templates import _GOOGLE, _GOOGLE_NATIVE, _NoRedirect, _google, _token


def _drive_request(endpoint, token, *, body, content_type):
    import truststore

    request = Request(endpoint, data=body, method="POST", headers={
        "Authorization": f"Bearer {token}", "Content-Type": content_type,
    })
    handler = HTTPSHandler(context=truststore.SSLContext(ssl.PROTOCOL_TLS_CLIENT))
    try:
        with build_opener(_NoRedirect(), handler).open(request, timeout=45) as response:
            return json.load(response)
    except HTTPError as error:
        raise RuntimeError(f"Google API returned HTTP {error.code}. Check the OAuth scope and your access.") from None
    except URLError:
        raise RuntimeError("Could not connect to the Google API.") from None


def _location(url):
    parts = urlsplit(url)
    match = re.fullmatch(r"/(document|spreadsheets|presentation)/d/([A-Za-z0-9_-]+)(?:/.*)?", parts.path)
    if parts.scheme != "https" or parts.hostname != "docs.google.com" or not match:
        raise ValueError("Use a native Google Docs, Sheets or Slides URL.")
    return match.groups()


def google_workspace(spec):
    action = spec["action"]
    if action == "export":
        filename, data, source = _google(spec["url"])
        path = output_file(spec["output"], "." + filename.rsplit(".", 1)[1])
        with path.open("xb") as destination:
            destination.write(data)
        return {"path": str(path), "source": source}
    if action == "import":
        source = scoped_path(spec["input"])
        office = {suffix: (kind, media) for kind, (suffix, media) in _GOOGLE.items()}
        if source.suffix.lower() not in office or not source.is_file():
            raise ValueError("Import a local DOCX, XLSX or PPTX file.")
        kind, mime = office[source.suffix.lower()]
        native = next(key for key, value in _GOOGLE_NATIVE.items() if value == kind)
        boundary = uuid4().hex
        metadata = json.dumps({"name": spec.get("name") or source.stem, "mimeType": native}, ensure_ascii=False).encode()
        body = (
            f"--{boundary}\r\nContent-Type: application/json; charset=UTF-8\r\n\r\n".encode() + metadata +
            f"\r\n--{boundary}\r\nContent-Type: {mime}\r\n\r\n".encode() + source.read_bytes() +
            f"\r\n--{boundary}--\r\n".encode()
        )
        query = urlencode({"uploadType": "multipart", "fields": "id,name,webViewLink"})
        return _drive_request(
            "https://www.googleapis.com/upload/drive/v3/files?" + query,
            _token("GOOGLE_WORKSPACE_WRITE_ACCESS_TOKEN"), body=body,
            content_type=f"multipart/related; boundary={boundary}",
        )
    if action == "batch_update":
        kind, identity = _location(spec["url"])
        api = {
            "document": ("https://docs.googleapis.com/v1/documents/", "GOOGLE_DOCS_WRITE_ACCESS_TOKEN"),
            "spreadsheets": ("https://sheets.googleapis.com/v4/spreadsheets/", "GOOGLE_SHEETS_WRITE_ACCESS_TOKEN"),
            "presentation": ("https://slides.googleapis.com/v1/presentations/", "GOOGLE_SLIDES_WRITE_ACCESS_TOKEN"),
        }
        endpoint, token = api[kind]
        changes = spec["requests"]
        if not isinstance(changes, list) or not changes or any(not isinstance(item, dict) or len(item) != 1 for item in changes):
            raise ValueError("Provide native batchUpdate requests for the selected Google file type.")
        payload = json.dumps({"requests": changes}).encode()
        return _drive_request(
            endpoint + identity + ":batchUpdate", _token(token), body=payload, content_type="application/json",
        )
    raise ValueError("Google Workspace actions are export, import and batch_update.")
