import json
import os
from pathlib import Path


def scoped_path(value):
    root = Path(os.environ.get("PORTABLE_SKILLS_WORKSPACE", Path.cwd())).resolve()
    path = (root / value).resolve()
    if not path.is_relative_to(root):
        raise ValueError("Path is outside PORTABLE_SKILLS_WORKSPACE.")
    return path


def read_json(value):
    return json.loads(scoped_path(value).read_text(encoding="utf-8-sig"))


def output_file(value, suffix):
    path = scoped_path(value)
    if path.suffix.lower() != suffix:
        raise ValueError(f"Choose a filename ending in {suffix}.")
    if path.exists():
        raise FileExistsError(f"Choose a new output path: {path.name}")
    path.parent.mkdir(parents=True, exist_ok=True)
    return path
