# 命令与输入格式

`portable.py` 的文档类命令接受 UTF-8 JSON 规格文件。路径相对于 `PORTABLE_SKILLS_WORKSPACE`，运行命令行时默认使用当前目录。写入路径必须是新文件。MCP 通过各工具的 `spec` 参数接收相同的对象。

## 本地 Word

命令为 `portable.py word SPEC.json`，MCP 工具为 `word_document`。

- `create` 接受 `output`、`title` 和可选的 `blocks`。块类型为 `paragraph`、`heading`、`bullet`、`table`。见 `examples/word.json`。
- `inspect` 接受 `input`。返回正文及表格文字、批注和修订计数。
- `replace` 和 `track` 接受 `input`、`output`、`find`、`replace`，替换所有精确匹配。`track` 支持 `author`，空替换会生成删除修订。见 `examples/word-track.json`。
- `comment` 接受 `input`、`output`、`find`、`text`、可选 `author`、`initials` 和从 1 开始的 `occurrence`。

## 本地 PDF

命令为 `portable.py pdf SPEC.json`，MCP 工具为 `pdf_document`。页码从 1 开始。

| 动作 | 参数 |
| --- | --- |
| `create` | `output`、`title`、可选 `paragraphs`。可用 `font` 指向可嵌入的 TrueType 文件。 |
| `inspect` | `input`，可选 `pages`。默认提取前三页并列出表单字段。 |
| `render` | `input`、PNG `output`、可选 `page` 和 `scale`。 |
| `merge` | 按顺序提供 `inputs` 和 PDF `output`。 |
| `select` | `input`、`pages`、PDF `output`。 |
| `fill` | `input`、PDF `output`、`fields`。先用 `inspect` 查看字段名，再传入如 `{"reviewer":"Lee"}` 的值。 |
| `ocr` | `input`，可选 `pages`、`language` 和 `scale`。需要 Tesseract 和相应语言包。中文简体可用语言代码 `chi_sim`。如果不在 PATH，设置 `PORTABLE_TESSERACT`。 [Tesseract 命令文档](https://tesseract-ocr.github.io/tessdoc/Command-Line-Usage.html) |

## 本地演示文稿

命令为 `portable.py presentation SPEC.json`，MCP 工具为 `powerpoint`。

- `create` 接受 `output` 和 `slides`。幻灯片支持 `title`、`bullets`、`notes`、`chart` 和可选的 `layout` 索引。可用 `template` 指定要在末尾追加幻灯片的现有 PPTX。见 `examples/presentation.json`。
- `inspect` 接受 `input`，返回各页内容、标题、图表数量和讲者备注。
- `replace` 接受 `input`、`output`、`find` 和 `replace`。修改普通形状中的匹配文本段。

## 本地表格

命令为 `portable.py spreadsheet SPEC.json`，MCP 工具为 `spreadsheet_workbook`。

- `create` 接受 `output` 和 `sheets`。工作表支持 `name`、`rows`、`header`、`freeze`、`widths` 和 `charts`。见 `examples/spreadsheet.json`。
- `inspect` 接受 `input`。可指定 `sheet`、A1 格式的 `range` 和 `cached_values`。未指定工作表时列出各工作表及已用区域。
- `write` 接受 `input`、`output`、`sheet`、单个起始单元格 `start` 和矩形 `rows`。可以附带与创建动作相同的格式和图表选项。
- `import_delimited` 和 `export_delimited` 接受 `input`、`output` 和 `sheet`，根据扩展名处理 UTF-8 CSV 或 TSV。导入时可省略 `sheet`，字段作为文字保留。
- `convert_legacy` 接受 XLS `input` 和 XLSX `output`，调用本地 LibreOffice 转换。

## 实时 Excel

命令为 `portable.py excel-live SPEC.json`，MCP 工具为 `live_excel`。`list` 发现打开的文件。其余操作都需要准确的 `workbook` 名称，`save` 外还需要 `sheet`。

```json
{
  "action": "write",
  "workbook": "Research.xlsx",
  "sheet": "Sheet1",
  "range": "A1:B2",
  "rows": [["Input", "Output"], [3, "=A2*2"]],
  "formulas": true
}
```

- `read` 接受 `range`。打开 `formulas` 可读公式。
- `format` 接受 `range` 和 `number_format`、`bold`、`fill` 中至少一项。
- `chart` 接受源 `range`、`kind`（`bar` 或 `line`）、`anchor`，可加 `title`。
- `calculate` 重算所选工作表。`save` 保存现有路径的工作簿。`export_pdf` 将所选工作表写到新的 `output`。

## Office 文件渲染

`portable.py office-pdf SPEC.json` 和 `office_export_pdf` 都接受 `input` 与 PDF `output`。需要已安装的 LibreOffice。若命令未加入 PATH，设置 `PORTABLE_LIBREOFFICE` 为命令的绝对路径。 [LibreOffice 命令文档](https://help.libreoffice.org/latest/en-US/text/shared/guide/start_parameters.html)

## 图像 API

`portable.py image SPEC.json` 和 `image_generate_edit` 都接受 `action`、`output` 和 `prompt`。编辑需要 `inputs`，可加 PNG `mask`。可指定 `model`、`size`、`quality` 和受该模型支持的 `background`。见 `examples/image.json`。 [图像模型与参数](https://developers.openai.com/api/docs/guides/image-generation)

## Google Workspace

`portable.py google SPEC.json` 和 `google_workspace` 共用以下格式。

| 动作 | 参数和凭据 |
| --- | --- |
| `export` | 原生 Docs、Slides、Sheets 或 Drive `url`，Office `output`。使用 `GOOGLE_DRIVE_ACCESS_TOKEN`。 |
| `import` | 本地 Office `input`，可选 `name`。使用 `GOOGLE_WORKSPACE_WRITE_ACCESS_TOKEN` 创建新的原生文件。 |
| `batch_update` | 原生文件 `url` 和服务支持的 `requests`。分别使用 `GOOGLE_DOCS_WRITE_ACCESS_TOKEN`、`GOOGLE_SHEETS_WRITE_ACCESS_TOKEN` 或 `GOOGLE_SLIDES_WRITE_ACCESS_TOKEN`。 |

导入需要 Drive 中可创建文件的 OAuth 权限。修改需要目标文件权限和对应服务的 OAuth scope。 [Drive 导入](https://developers.google.com/workspace/drive/api/guides/manage-uploads) · [Docs 修改](https://developers.google.com/workspace/docs/api/reference/rest/v1/documents/batchUpdate) · [Sheets 修改](https://developers.google.com/workspace/sheets/api/reference/rest/v4/spreadsheets/batchUpdate) · [Slides 修改](https://developers.google.com/workspace/slides/api/reference/rest/v1/presentations/batchUpdate)
