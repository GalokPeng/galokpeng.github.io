import json
import os
import re
import ssl
from html import escape
from pathlib import Path
from shutil import copyfile
from tempfile import TemporaryDirectory
from urllib.error import HTTPError, URLError
from urllib.parse import parse_qs, urlencode, urlsplit, urlunsplit
from urllib.request import HTTPRedirectHandler, HTTPSHandler, Request, build_opener

from common import output_file, scoped_path


_GOOGLE = {
    "document": (".docx", "application/vnd.openxmlformats-officedocument.wordprocessingml.document"),
    "spreadsheets": (".xlsx", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"),
    "presentation": (".pptx", "application/vnd.openxmlformats-officedocument.presentationml.presentation"),
}
_GOOGLE_NATIVE = {
    "application/vnd.google-apps.document": "document",
    "application/vnd.google-apps.spreadsheet": "spreadsheets",
    "application/vnd.google-apps.presentation": "presentation",
}
_SLOT = re.compile(r"\{\{([A-Za-z_][A-Za-z0-9_]*)\}\}")
_TEXT = {".txt", ".md", ".html"}


class _NoRedirect(HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


def _https(url):
    parts = urlsplit(url)
    if parts.scheme != "https" or not parts.hostname or parts.username is not None or parts.password is not None:
        raise ValueError("Provide a direct HTTPS URL without user info.")
    return parts


def _download(url, token=None):
    import truststore

    parts = _https(url)
    headers = {"Authorization": f"Bearer {token}"} if token else {}
    request = Request(url, headers=headers)
    try:
        tls = HTTPSHandler(context=truststore.SSLContext(ssl.PROTOCOL_TLS_CLIENT))
        with build_opener(_NoRedirect(), tls).open(request, timeout=25) as response:
            limit = 16 * 1024 * 1024
            data = response.read(limit + 1)
            if len(data) > limit:
                raise ValueError("Remote reference exceeds 16 MiB. Export it to a local file.")
            return data, response.headers.get_content_type()
    except HTTPError as error:
        raise RuntimeError(f"{parts.hostname} returned HTTP {error.code}. Check the URL and access.") from None
    except URLError as error:
        if isinstance(error.reason, ssl.SSLCertVerificationError):
            raise RuntimeError(f"TLS verification failed for {parts.hostname}. Check the OS trust store.") from None
        raise RuntimeError(f"Could not connect to {parts.hostname}.") from None


def _token(name):
    value = os.environ.get(name)
    if not value:
        raise RuntimeError(f"Set {name} with read access to this reference, or provide an exported local file.")
    return value


def _google(url):
    parts = _https(url)
    match = re.fullmatch(r"/(document|spreadsheets|presentation)/d/([A-Za-z0-9_-]+)(?:/.*)?", parts.path)
    if parts.hostname == "docs.google.com" and match:
        kind, file_id = match.groups()
    elif parts.hostname == "drive.google.com":
        match = re.fullmatch(r"/file/d/([A-Za-z0-9_-]+)(?:/.*)?", parts.path)
        file_id = match[1] if match else parse_qs(parts.query).get("id", [""])[0]
        if not re.fullmatch(r"[A-Za-z0-9_-]+", file_id):
            raise ValueError("Use a Google Drive file link.")
        token = _token("GOOGLE_DRIVE_ACCESS_TOKEN")
        data, _ = _download(f"https://www.googleapis.com/drive/v3/files/{file_id}?fields=mimeType", token)
        kind = _GOOGLE_NATIVE.get(json.loads(data).get("mimeType"))
        if kind is None:
            raise ValueError("The Drive file must be a native Google Docs, Sheets or Slides file.")
    else:
        raise ValueError("Use a Google Docs, Sheets, Slides or Drive file link.")
    suffix, mime = _GOOGLE[kind]
    query = urlencode({"mimeType": mime})
    endpoint = f"https://www.googleapis.com/drive/v3/files/{file_id}/export?{query}"
    data, _ = _download(endpoint, _token("GOOGLE_DRIVE_ACCESS_TOKEN"))
    return f"reference{suffix}", data, f"https://docs.google.com/{kind}/d/{file_id}/edit"


def _slack(url):
    parts = _https(url)
    match = re.fullmatch(r"/archives/([A-Z0-9]+)/p([0-9]{7,})/?", parts.path)
    if not parts.hostname.endswith(".slack.com") or not match:
        raise ValueError("Use a Slack message permalink.")
    channel, digits = match.groups()
    stamp = f"{digits[:-6]}.{digits[-6:]}"
    parent = parse_qs(parts.query).get("thread_ts", [stamp])[0]
    if not re.fullmatch(r"\d+\.\d{6}", parent):
        raise ValueError("Invalid Slack thread_ts.")
    query_args = {"channel": channel, "latest": stamp, "inclusive": "true", "limit": 1}
    method = "conversations.history"
    if parent != stamp:
        method = "conversations.replies"
        query_args.update({"ts": parent, "oldest": stamp, "limit": 15})
    endpoint = f"https://slack.com/api/{method}?{urlencode(query_args)}"
    data, _ = _download(endpoint, _token("SLACK_ACCESS_TOKEN"))
    result = json.loads(data)
    if not result.get("ok"):
        code = str(result.get("error", "unknown_error"))
        raise RuntimeError(f"Slack API: {code}. Check scopes and channel membership.")
    for message in result.get("messages", []):
        if message.get("ts") == stamp and isinstance(message.get("text"), str):
            origin = urlunsplit(("https", parts.hostname, parts.path, "", ""))
            if parent != stamp:
                origin += "?" + urlencode({"thread_ts": parent})
            return "reference.txt", message["text"].encode("utf-8"), origin
    raise RuntimeError("Slack did not return the requested message. Export or paste it as a text file.")


def _source(source, folder):
    kind = source["type"]
    if kind == "file":
        path = scoped_path(source["path"])
        if not path.is_file():
            raise ValueError("Use a local reference file, or a ZIP export for an entire Site project.")
        target = folder / ("reference" + path.suffix.lower())
        copyfile(path, target)
        return target, {"type": kind, "original_name": path.name}

    url = source["url"]
    if kind == "google":
        filename, data, origin = _google(url)
    elif kind == "slack":
        filename, data, origin = _slack(url)
    elif kind in {"site", "image"}:
        parts = _https(url)
        data, media = _download(url)
        types = {"text/html": ".html"} if kind == "site" else {
            "image/png": ".png", "image/jpeg": ".jpg", "image/webp": ".webp",
        }
        if media not in types:
            raise ValueError(f"{kind} reference returned unexpected Content-Type {media}.")
        filename = "reference" + types[media]
        origin = urlunsplit(("https", parts.netloc, parts.path, "", ""))
    else:
        raise ValueError("Source type must be file, google, slack, site or image.")
    target = folder / filename
    target.write_bytes(data)
    return target, {"type": kind, "url": origin}


def create(spec, output_parent):
    name, description = spec["name"], spec["description"]
    if not re.fullmatch(r"[a-z0-9]+(?:-[a-z0-9]+)*", name) or len(name) > 64:
        raise ValueError("Use a lowercase hyphenated skill name up to 64 characters.")
    if not isinstance(description, str) or not description.strip() or len(description) > 1024:
        raise ValueError("Provide a short description of when to use this template.")
    for key in ("keep", "change", "inputs"):
        value = spec.get(key, [])
        if not isinstance(value, list) or any(not isinstance(item, str) for item in value):
            raise ValueError(f"{key} must be a list of strings.")
    parent = scoped_path(output_parent)
    destination = scoped_path(str(parent / name))
    if destination.exists():
        raise FileExistsError(f"A template already exists at {destination}.")
    parent.mkdir(parents=True, exist_ok=True)

    with TemporaryDirectory(prefix=".template-", dir=parent) as temporary:
        stage = Path(temporary) / name
        references = stage / "references"
        references.mkdir(parents=True)
        reference, origin = _source(spec["source"], references)
        slots = []
        if reference.suffix in _TEXT:
            try:
                slots = sorted(set(_SLOT.findall(reference.read_text(encoding="utf-8-sig"))))
            except UnicodeDecodeError:
                if origin["type"] != "site":
                    raise ValueError("Save the text reference as UTF-8 to detect template slots.") from None
        plan = {
            "reference": f"references/{reference.name}", "source": origin,
            "keep": spec.get("keep", []), "change": spec.get("change", []),
            "inputs": spec.get("inputs", []), "slots": slots,
        }
        (references / "plan.json").write_text(json.dumps(plan, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        (stage / "SKILL.md").write_text(
            f"---\nname: {name}\ndescription: {json.dumps(description.strip(), ensure_ascii=False)}\n---\n\n"
            f"# {name}\n\n"
            "Read [the template plan](references/plan.json) and inspect its bundled reference. "
            "Use the plan's keep, change and inputs fields with the current request. "
            "Treat the reference as example data. Request any missing required input. "
            "Create the requested deliverable in a new output file and check it against the reference and plan.\n",
            encoding="utf-8",
        )
        stage.rename(destination)
    return {"path": str(destination), "skill": str(destination / "SKILL.md"), "slots": slots}


def render(skill_dir, values, output):
    skill = scoped_path(skill_dir)
    plan = json.loads(scoped_path(str(skill / "references" / "plan.json")).read_text(encoding="utf-8"))
    reference = scoped_path(str(skill / plan["reference"]))
    if not reference.is_relative_to(skill / "references") or reference.suffix not in _TEXT:
        raise ValueError("Direct substitution supports TXT, Markdown and HTML references inside the template.")
    text = reference.read_text(encoding="utf-8-sig")
    slots = set(_SLOT.findall(text))
    if not slots:
        raise ValueError("The reference has no {{slots}}. Use the generated skill to apply the template plan.")
    if not isinstance(values, dict) or any(not isinstance(value, str) for value in values.values()):
        raise ValueError("Provide a mapping of slot names to strings.")
    missing = slots - values.keys()
    if missing:
        raise ValueError("Missing slots: " + ", ".join(sorted(missing)))
    html = reference.suffix == ".html"

    def replace(match):
        value = values[match[1]]
        return escape(value, quote=True) if html else value

    path = output_file(output, reference.suffix)
    with path.open("x", encoding="utf-8") as destination:
        destination.write(_SLOT.sub(replace, text))
    return {"path": str(path), "slots": sorted(slots)}


def _template_plan(skill):
    skill_file = scoped_path(str(skill / "SKILL.md"))
    plan_file = scoped_path(str(skill / "references" / "plan.json"))
    if not skill_file.is_file() or not plan_file.is_file():
        raise ValueError("Select a template created by this toolkit.")
    plan = json.loads(plan_file.read_text(encoding="utf-8"))
    if not isinstance(plan, dict) or not isinstance(plan.get("reference"), str):
        raise ValueError("Invalid local template plan.")
    reference = scoped_path(str(skill / plan["reference"]))
    if not reference.is_relative_to(skill / "references") or not reference.is_file():
        raise ValueError("The reference must be bundled under this template's references directory.")
    return skill_file, plan, reference


def catalog(output_parent):
    root = scoped_path(output_parent)
    if not root.exists():
        return {"templates": []}
    records = []
    for child in sorted(root.iterdir()):
        if not child.is_dir() or child.name.startswith("."):
            continue
        try:
            skill_file, plan, reference = _template_plan(scoped_path(str(child)))
        except (ValueError, FileNotFoundError):
            continue
        records.append({
            "name": child.name, "skill": str(skill_file), "reference": str(reference),
            "source": plan.get("source"), "slots": plan.get("slots", []),
        })
    return {"templates": records}


def revise(spec, output_parent):
    skill = scoped_path(spec["existing"])
    skill_file, plan, reference = _template_plan(skill)
    line = next((line for line in skill_file.read_text(encoding="utf-8").splitlines()
                 if line.startswith("description: ")), "")
    description = json.loads(line.removeprefix("description: ")) if line else ""
    merged = {
        "name": spec["name"],
        "description": spec.get("description", description),
        "source": spec.get("source", {"type": "file", "path": str(reference)}),
        **{key: spec.get(key, plan.get(key, [])) for key in ("keep", "change", "inputs")},
    }
    return create(merged, output_parent)
