from contextlib import contextmanager
import re
import sys

from common import output_file


_A1 = re.compile(r"\$?[A-Z]{1,3}\$?[1-9][0-9]{0,6}(?::\$?[A-Z]{1,3}\$?[1-9][0-9]{0,6})?", re.I)


@contextmanager
def _attached():
    if sys.platform != "win32":
        raise RuntimeError("The live Excel adapter requires Windows desktop Excel.")
    import pythoncom
    from pywintypes import com_error
    from win32com.client import GetActiveObject

    pythoncom.CoInitialize()
    try:
        try:
            app = GetActiveObject("Excel.Application")
        except com_error:
            raise RuntimeError("Open desktop Excel, open the workbook and switch focus away from Excel so it registers with Windows.") from None
        try:
            yield app
        finally:
            del app
    finally:
        pythoncom.CoUninitialize()


def _primitive(value):
    return value.isoformat() if hasattr(value, "isoformat") else value


def _tabular(value, height, width):
    if height == width == 1:
        return [[_primitive(value)]]
    return [[_primitive(cell) for cell in row] for row in value]


def _operate(app, spec):
    action = spec["action"]
    if action == "list":
        return {"workbooks": [{"name": str(book.Name), "sheets": [str(sheet.Name) for sheet in book.Worksheets]} for book in app.Workbooks]}
    if action not in {"read", "write", "calculate", "save", "format", "chart", "export_pdf"}:
        raise ValueError("Live Excel actions are list, read, write, calculate, save, format, chart and export_pdf.")
    book = app.Workbooks.Item(spec["workbook"])
    if str(book.Name).casefold() != spec["workbook"].casefold():
        raise ValueError("Select the exact workbook name from list.")
    if action == "save":
        if not book.Path or book.ReadOnly:
            raise ValueError("Save requires a writable workbook with an existing path.")
        book.Save()
        return {"workbook": str(book.Name), "saved": True}

    sheet = book.Worksheets.Item(spec["sheet"])
    if action == "export_pdf":
        path = output_file(spec["output"], ".pdf")
        sheet.ExportAsFixedFormat(0, str(path))
        return {"workbook": str(book.Name), "sheet": str(sheet.Name), "path": str(path)}
    if action == "calculate":
        sheet.Calculate()
        return {"workbook": str(book.Name), "sheet": str(sheet.Name), "calculated": True}

    address = spec["range"]
    if not _A1.fullmatch(address):
        raise ValueError("Select a bounded A1 rectangle within the named sheet.")
    region = sheet.Range(address)
    height, width = int(region.Rows.Count), int(region.Columns.Count)
    if height * width > 5000:
        raise ValueError("Select up to 5,000 cells per operation.")
    if action in {"write", "format", "chart"} and book.ReadOnly:
        raise ValueError("Select a writable workbook.")
    if action == "format":
        number_format = spec.get("number_format")
        bold = spec.get("bold")
        fill = None
        if number_format is not None and not isinstance(number_format, str):
            raise ValueError("number_format must be an Excel format string.")
        if bold is not None and type(bold) is not bool:
            raise ValueError("bold must be true or false.")
        if "fill" in spec:
            color = spec["fill"].removeprefix("#")
            if not re.fullmatch(r"[a-fA-F0-9]{6}", color):
                raise ValueError("Use a six-digit RGB fill color.")
            red, green, blue = bytes.fromhex(color)
            fill = red | green << 8 | blue << 16
        if all(value is None for value in (number_format, bold, fill)):
            raise ValueError("Provide number_format, bold or fill.")
        if number_format is not None:
            region.NumberFormat = number_format
        if bold is not None:
            region.Font.Bold = bold
        if fill is not None:
            region.Interior.Color = fill
        return {"workbook": str(book.Name), "sheet": str(sheet.Name), "range": address, "formatted": True}
    if action == "chart":
        anchor = spec["anchor"]
        if not _A1.fullmatch(anchor) or ":" in anchor:
            raise ValueError("Supply a single chart anchor cell such as E2.")
        target = sheet.Range(anchor)
        chart_type = {"bar": 51, "line": 4}[spec["kind"]]
        chart_object = sheet.ChartObjects().Add(target.Left, target.Top, 360, 220)
        try:
            chart = chart_object.Chart
            chart.ChartType = chart_type
            chart.SetSourceData(region)
            if "title" in spec:
                chart.HasTitle = True
                chart.ChartTitle.Text = spec["title"]
            return {"workbook": str(book.Name), "sheet": str(sheet.Name), "chart": str(chart_object.Name)}
        except Exception:
            chart_object.Delete()
            raise
    if action == "write":
        rows = spec["rows"]
        if len(rows) != height or any(not isinstance(row, list) or len(row) != width for row in rows):
            raise ValueError("Write data must exactly match the selected range.")
        if spec.get("formulas", False):
            region.Formula = rows[0][0] if height == width == 1 else tuple(tuple(row) for row in rows)
        else:
            # Excel interprets a leading equals sign even on some Value2 writes.
            safe_rows = [tuple("'" + item if isinstance(item, str) and item.startswith("=") else item for item in row) for row in rows]
            region.Value2 = safe_rows[0][0] if height == width == 1 else tuple(safe_rows)
    value = region.Formula if spec.get("formulas", False) else region.Value2
    return {"workbook": str(book.Name), "sheet": str(sheet.Name), "range": address, "rows": _tabular(value, height, width)}


def excel_live(spec):
    with _attached() as app:
        try:
            return _operate(app, spec)
        finally:
            del app
