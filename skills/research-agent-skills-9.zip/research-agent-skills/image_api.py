import base64
from contextlib import ExitStack
import os

from common import output_file, scoped_path


def image(spec, *, client=None):
    action = spec["action"]
    if action not in {"generate", "edit"}:
        raise ValueError("Image actions are generate and edit.")
    if not spec["prompt"].strip():
        raise ValueError("Describe the image or requested edit.")
    path = output_file(spec["output"], ".png")
    options = {"model": spec.get("model", "gpt-image-2"), "prompt": spec["prompt"], "output_format": "png"}
    for key in ("size", "quality", "background"):
        if key in spec:
            options[key] = spec[key]

    with ExitStack() as resources:
        if client is None:
            if not os.environ.get("OPENAI_API_KEY"):
                raise RuntimeError("Set OPENAI_API_KEY in the process environment.")
            from openai import OpenAI

            client = resources.enter_context(OpenAI(timeout=180, max_retries=0))
        if action == "edit":
            image_paths = [scoped_path(item) for item in spec["inputs"]]
            if not image_paths:
                raise ValueError("Provide at least one reference image for an edit.")
            options["image"] = [resources.enter_context(item.open("rb")) for item in image_paths]
            if "mask" in spec:
                options["mask"] = resources.enter_context(scoped_path(spec["mask"]).open("rb"))
            response = client.images.edit(**options)
        else:
            response = client.images.generate(**options)

    if not response.data or not response.data[0].b64_json:
        raise RuntimeError("The image service did not return PNG data.")
    data = base64.b64decode(response.data[0].b64_json, validate=True)
    if not data.startswith(b"\x89PNG\r\n\x1a\n"):
        raise RuntimeError("The response was not PNG.")
    with path.open("xb") as destination:
        destination.write(data)
    return {"path": str(path), "model": options["model"], "bytes": len(data)}
