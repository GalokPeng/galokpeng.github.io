import json
import math
from functools import lru_cache
from html import escape
from pathlib import Path

from common import output_file


def _label(value):
    return escape(str(value), quote=False)


def _scatter(go, series, kind="line"):
    x, y = series["x"], series["y"]
    if not isinstance(x, list) or not isinstance(y, list) or len(x) != len(y) or not x:
        raise ValueError("Each series needs equally sized, nonempty x and y arrays.")
    x = [_label(value) if isinstance(value, str) else value for value in x]
    params = {"x": x, "y": y, "name": _label(series.get("name", ""))}
    if kind == "bar":
        return go.Bar(**params)
    return go.Scatter(**params, mode="markers" if kind == "scatter" else "lines")


def _simulation(go, spec):
    scenarios = spec["scenarios"]
    if not isinstance(scenarios, list) or not 2 <= len(scenarios) <= 80:
        raise ValueError("A simulation needs 2–80 scenarios.")
    steps = []
    y_values = []
    for scenario in scenarios:
        values = scenario["y"]
        if len(values) != len(spec["x"]) or any(
            not isinstance(value, (int, float)) or not math.isfinite(value) for value in values
        ):
            raise ValueError("Simulation scenarios need finite y values matching x.")
        label = _label(scenario["label"])
        steps.append({"label": label, "method": "restyle", "args": [{"y": [values]}]})
        y_values.extend(values)
    figure = go.Figure(_scatter(go, {"x": spec["x"], "y": scenarios[0]["y"]}))
    low, high = min(y_values), max(y_values)
    margin = (high - low) * 0.06 or max(abs(low) * 0.06, 1)
    figure.update_yaxes(range=[low - margin, high + margin])
    figure.update_layout(sliders=[{
        "steps": steps,
        "currentvalue": {"prefix": _label(spec.get("parameter", "")) + " "},
        "pad": {"t": 30},
    }])
    return figure


@lru_cache(maxsize=1)
def _land():
    data = json.loads((Path(__file__).parent / "assets" / "land.json").read_text(encoding="utf-8"))
    return data["x"], data["y"]


def _map(go, spec):
    xs, ys = _land()
    figure = go.Figure(go.Scatter(
        x=xs, y=ys, mode="lines", line={"width": 0.6, "color": "#86aaa9"},
        fill="toself", fillcolor="#dbe9d8", hoverinfo="skip", showlegend=False,
    ))
    for point in spec["points"]:
        if not -180 <= point["lon"] <= 180 or not -90 <= point["lat"] <= 90:
            raise ValueError("Map points need longitude -180–180 and latitude -90–90.")
    figure.add_trace(go.Scatter(
        x=[point["lon"] for point in spec["points"]],
        y=[point["lat"] for point in spec["points"]],
        text=[_label(point["label"]) for point in spec["points"]],
        mode="markers", marker={"size": 10, "color": "#c54c3a", "line": {"color": "white", "width": 1.5}},
        hovertemplate="%{text}<br>%{y:.2f}°, %{x:.2f}°<extra></extra>", showlegend=False,
    ))
    figure.update_xaxes(range=[-180, 180], visible=False)
    figure.update_yaxes(range=[-90, 90], visible=False, scaleanchor="x", scaleratio=1)
    figure.update_layout(plot_bgcolor="#eaf3f6", dragmode="pan")
    return figure


def _figure(spec):
    import plotly.graph_objects as go

    kind = spec["kind"]
    if kind in {"line", "bar", "scatter"}:
        if not spec["series"]:
            raise ValueError("Provide at least one data series.")
        figure = go.Figure([_scatter(go, series, kind) for series in spec["series"]])
    elif kind == "simulation":
        figure = _simulation(go, spec)
    elif kind == "map":
        figure = _map(go, spec)
    else:
        raise ValueError("kind must be line, bar, scatter, simulation or map.")
    title = _label(spec["title"])
    figure.update_layout(
        template="plotly_white", autosize=True, margin={"l": 55, "r": 25, "t": 26, "b": 60},
        font={"family": "system-ui, sans-serif", "color": "#152a3a"},
        colorway=["#1a7069", "#c54c3a", "#4463a5", "#8a6421"],
        xaxis_title=_label(spec.get("x_title", "")), yaxis_title=_label(spec.get("y_title", "")),
    )
    return title, figure


def inline(spec):
    from plotly.utils import PlotlyJSONEncoder

    _, figure = _figure(spec)
    payload = json.loads(json.dumps(figure.to_dict(), cls=PlotlyJSONEncoder))
    return {"title": str(spec["title"]), "data": payload["data"], "layout": payload["layout"]}


def app_html():
    from plotly.offline import get_plotlyjs

    script = (Path(__file__).parent / "assets" / "plotly-app.js").read_text(encoding="utf-8")
    return (
        '<!doctype html><html lang="en"><meta charset="utf-8">'
        '<meta name="viewport" content="width=device-width,initial-scale=1">'
        '<title>Interactive chart</title><style>'
        'body{margin:12px;color:#152a3a;font:15px system-ui,sans-serif}'
        'h1{font-size:1.2rem;margin:0 0 8px}#plot{height:min(58vh,520px);min-height:300px}'
        '</style><main><h1 id="title">Interactive chart</h1><p id="status" role="status">Waiting for chart data</p>'
        '<div id="plot"></div></main>'
        f'<script>{get_plotlyjs()}</script><script>{script}</script></html>'
    )


def build(spec, output):
    from plotly.offline import get_plotlyjs
    from plotly.utils import PlotlyJSONEncoder

    title, figure = _figure(spec)
    kind = spec["kind"]
    encoded = json.dumps(figure.to_dict(), cls=PlotlyJSONEncoder, ensure_ascii=True).replace("<", "\\u003c")
    credit = '<footer>Basemap from <a href="https://www.naturalearthdata.com/">Natural Earth</a></footer>' if kind == "map" else ""
    document = (
        '<!doctype html><html lang="en"><meta charset="utf-8">'
        '<meta name="viewport" content="width=device-width,initial-scale=1">'
        f'<title>{title}</title><style>'
        'body{margin:0;color:#152a3a;background:#f6f8f8;font:16px system-ui,sans-serif}'
        'main{max-width:1100px;margin:32px auto;padding:0 16px}h1{font-size:clamp(22px,4vw,34px)}'
        '#plot{height:min(70vh,630px);min-height:340px;background:white;border:1px solid #dce5e3}'
        'footer{margin-top:10px;font-size:13px}a{color:#1a7069}</style>'
        f'<main><h1>{title}</h1><div id="plot"></div>{credit}</main>'
        f'<script>{get_plotlyjs()}</script><script id="figure" type="application/json">{encoded}</script>'
        '<script>const spec=JSON.parse(document.getElementById("figure").textContent);'
        'Plotly.newPlot("plot",spec.data,spec.layout,{responsive:true,displaylogo:false,scrollZoom:true});'
        '</script></html>'
    )
    path = output_file(output, ".html")
    with path.open("x", encoding="utf-8") as destination:
        destination.write(document)
    return {"kind": kind, "path": str(path), "file_url": path.as_uri(), "bytes": path.stat().st_size}
