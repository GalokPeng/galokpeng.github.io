# Operations update · {{week}}

## Summary

{{summary}}

## Next action

{{next_action}}
