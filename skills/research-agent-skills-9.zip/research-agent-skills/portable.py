import argparse
import json
import sys

import desktop
import excel_live
import google_bridge
import image_api
import office_bridge
import office_files
import pdf_tools
import templates
import visuals
from common import output_file, read_json


def _capture(hwnd, output, mode):
    metadata, data = desktop.capture(hwnd, mode)
    path = output_file(output, ".png")
    with path.open("xb") as destination:
        destination.write(data)
    return {**metadata, "path": str(path)}


def main():
    parser = argparse.ArgumentParser(description="Portable research tools. All document commands take a local JSON specification.")
    commands = parser.add_subparsers(dest="command", required=True)
    desk = commands.add_parser("desktop").add_subparsers(dest="action", required=True)
    windows = desk.add_parser("windows")
    windows.add_argument("--title", default="")
    windows.set_defaults(run=lambda a: desktop.windows(a.title))
    tree = desk.add_parser("tree")
    tree.add_argument("hwnd", type=int)
    tree.add_argument("--depth", type=int, default=3)
    tree.add_argument("--limit", type=int, default=100)
    tree.set_defaults(run=lambda a: desktop.tree(a.hwnd, a.depth, a.limit))
    capture = desk.add_parser("capture")
    capture.add_argument("hwnd", type=int)
    capture.add_argument("output")
    capture.add_argument("--mode", choices=("gdi", "graphics"), default="gdi")
    capture.set_defaults(run=lambda a: _capture(a.hwnd, a.output, a.mode))
    click = desk.add_parser("click")
    click.add_argument("hwnd", type=int)
    click.add_argument("x", type=int)
    click.add_argument("y", type=int)
    click.add_argument("--button", choices=("left", "right", "middle"), default="left")
    click.set_defaults(run=lambda a: desktop.click(a.hwnd, a.x, a.y, a.button))
    for name, action in (("keys", desktop.keys), ("text", desktop.text)):
        command = desk.add_parser(name)
        command.add_argument("hwnd", type=int)
        command.add_argument("value")
        command.set_defaults(run=lambda a, action=action: action(a.hwnd, a.value))

    render = commands.add_parser("visualize")
    render.add_argument("spec")
    render.add_argument("output")
    render.set_defaults(run=lambda a: visuals.build(read_json(a.spec), a.output))

    tpl = commands.add_parser("template").add_subparsers(dest="action", required=True)
    create = tpl.add_parser("create")
    create.add_argument("spec")
    create.add_argument("output_parent")
    create.set_defaults(run=lambda a: templates.create(read_json(a.spec), a.output_parent))
    fill = tpl.add_parser("render")
    fill.add_argument("skill_dir")
    fill.add_argument("values")
    fill.add_argument("output")
    fill.set_defaults(run=lambda a: templates.render(a.skill_dir, read_json(a.values), a.output))
    catalog = tpl.add_parser("list")
    catalog.add_argument("output_parent")
    catalog.set_defaults(run=lambda a: templates.catalog(a.output_parent))
    revise = tpl.add_parser("revise")
    revise.add_argument("spec")
    revise.add_argument("output_parent")
    revise.set_defaults(run=lambda a: templates.revise(read_json(a.spec), a.output_parent))

    for name, action in (
        ("word", office_files.word), ("pdf", pdf_tools.pdf),
        ("presentation", office_files.presentation), ("spreadsheet", office_files.spreadsheet),
        ("excel-live", excel_live.excel_live), ("image", image_api.image),
        ("office-pdf", office_bridge.office_pdf), ("google", google_bridge.google_workspace),
    ):
        command = commands.add_parser(name)
        command.add_argument("spec")
        command.set_defaults(run=lambda a, action=action: action(read_json(a.spec)))

    args = parser.parse_args()
    try:
        print(json.dumps(args.run(args), ensure_ascii=True, indent=2))
    except Exception as error:
        print(f"{type(error).__name__}: {error}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
