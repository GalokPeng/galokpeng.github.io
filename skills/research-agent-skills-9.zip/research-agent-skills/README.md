# 9 项可移植 Agent Skills 研究套件

套件包含九个 `SKILL.md`、一套独立 Python 源码、标准 MCP stdio 服务和命令行。支持 Skills 的 agent 可以导入 `skills/` 下需要的目录。支持 MCP 或能运行命令行的 agent 可以直接调用工具。

| 能力 | 包内实现 | 运行条件 |
| --- | --- | --- |
| Word | 创建、检查、跨格式区段替换文字、批注和修订 | 本地 DOCX |
| PDF | 创建、文字提取、PNG 渲染、合并、选页、填写现有 AcroForm 及扫描件 OCR | 扫描件提取文字需要 Tesseract |
| 演示文稿 | 创建和编辑 PPTX，支持柱状图、折线图、备注和既有主题文件 | 本地 PPTX |
| 表格文件 | 创建和编辑 XLSX，处理公式、格式、冻结区域、图表及 CSV/TSV | 公式用表格引擎重算 |
| 实时 Excel | 列出工作簿，读取、写入、格式化、绘图、重算、保存和导出 PDF | Windows 桌面 Excel |
| ImageGen | 用公开 Images API 生成、编辑和遮罩编辑 PNG | `OPENAI_API_KEY`，请求可能产生费用 |
| Windows 操作 | 窗口发现、UI Automation 树、截图、点击、快捷键和输入 | 已登录的 Windows 图形会话 |
| 可视化 | 图表、预计算场景滑块、世界点位图 | 浏览器可离线打开。聊天内嵌需要 MCP Apps 客户端 |
| 模板 | 从参考材料建立模板、填充占位符、列出模板和生成新版本 | 本地模板库。Google 和 Slack 需要有权限的 token |

## 安装

在解压后的目录里用 Python 3.11 或更新版本运行。

```powershell
python -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe portable.py --help
```

macOS 和 Linux 的虚拟环境解释器为 `.venv/bin/python`。两个桌面适配器需要 Windows。其他工具使用跨平台依赖，本包在 Windows 上验证。

将 `mcp.example.json` 的条目添加到 agent 的 MCP 配置，并替换其中的绝对路径。服务入口为 `mcp_server.py`。`PORTABLE_SKILLS_WORKSPACE` 指定工具可读写的文件目录。命令行默认使用当前目录。首次运行下面的示例时，将项目根目录设为工作区。

如果 agent 和 MCP 服务在不同设备上，Windows 操作仍需要在目标 Windows 图形会话中运行。HTML 文件也需要通过 agent 的附件机制或共享文件系统交付。

## Word、PDF、PPTX 和 XLSX

解压后切到套件根目录，执行这些示例会在 `demo/` 里生成新文件。

```powershell
.\.venv\Scripts\python.exe portable.py word examples/word.json
.\.venv\Scripts\python.exe portable.py word examples/word-track.json
.\.venv\Scripts\python.exe portable.py pdf examples/pdf.json
.\.venv\Scripts\python.exe portable.py pdf examples/pdf-render.json
.\.venv\Scripts\python.exe portable.py presentation examples/presentation.json
.\.venv\Scripts\python.exe portable.py spreadsheet examples/spreadsheet.json
```

[命令与输入格式](COMMANDS.md) 包含已有文件的读写、Word 批注、PDF 选页与表单等例子。选装 LibreOffice 后可用 `office-pdf` 将 Office 文件渲染为 PDF，然后逐页检查。

## 实时 Excel 和 ImageGen

打开目标 Excel 工作簿，把焦点切离 Excel 后执行 `portable.py excel-live examples/excel-live.json`。选择列表中的工作簿和工作表，再按 [命令参考](COMMANDS.md) 指定 A1 区域。写入作用于打开的工作簿，保存使用单独操作。

给进程设置 `OPENAI_API_KEY` 后，可以运行 `portable.py image examples/image.json`。生成和编辑都会调用真实图像 API。示例中只含提示词，图像文件由运行时生成。 [OpenAI Images API](https://developers.openai.com/api/docs/guides/image-generation)

有原生 Google Workspace 需求时，可以通过 `portable.py google SPEC.json` 导出 DOCX、XLSX、PPTX，导入为新的 Google 文件，或发送对应服务的原生 `batchUpdate` 指令。写入凭据和请求结构见 [命令参考](COMMANDS.md)。

## Windows 操作

```powershell
.\.venv\Scripts\python.exe portable.py desktop windows --title "Notepad"
.\.venv\Scripts\python.exe portable.py desktop tree 12345
.\.venv\Scripts\python.exe portable.py desktop capture 12345 demo/window.png
```

把 `12345` 换成窗口列表返回的句柄。标题匹配不区分大小写。可用命令还有 `desktop click HWND X Y`、`desktop keys HWND Ctrl+S` 和 `desktop text HWND "要输入的文字"`。点击坐标以目标窗口左上角为原点，单位是物理像素。UI Automation 树使用屏幕坐标。截图在 MCP 中作为 PNG 返回。

输入会聚焦目标窗口。最小化窗口需先恢复。部分 GPU 加速、遮挡或受保护的窗口可能返回空白图像。对支持 Windows Graphics Capture 的窗口可选装 `windows-capture>=2,<3`，然后使用 `desktop capture HWND OUTPUT.png --mode graphics`，或给 MCP 截图工具传入 `mode: "graphics"`。截图元数据中的 `click_offset` 需要加到图中坐标后才能用于点击，空值时使用 UI Automation 屏幕坐标。Windows 会限制对更高权限窗口的输入。 [Windows Graphics Capture 依赖](https://github.com/NiiightmareXD/windows-capture)

## 可视化

```powershell
.\.venv\Scripts\python.exe portable.py visualize examples/line.json demo/line.html
.\.venv\Scripts\python.exe portable.py visualize examples/simulation.json demo/simulation.html
.\.venv\Scripts\python.exe portable.py visualize examples/map.json demo/map.html
```

生成的 HTML 内含 Plotly.js 和数据，用浏览器打开即可交互。`examples/simulation-demo.html` 可以直接打开。聊天中能否内嵌，取决于 agent 客户端的 HTML 预览能力。

支持 MCP Apps 的客户端可调用 `visualize_inline`。服务通过 `ui://research-agent-skills/chart.html` 提供图表界面和协议握手。 [MCP Apps 规范](https://github.com/modelcontextprotocol/ext-apps/blob/main/specification/2026-01-26/apps.mdx)

内置示例使用 Plotly.js 3.7.0。许可文本见 `assets/PLOTLY-LICENSE.txt`。 [Plotly HTML 导出指南](https://plotly.com/python/interactive-html-export/)

- `line`、`bar` 和 `scatter` 接受一个或多个含 `x`、`y` 和可选 `name` 的系列。
- `simulation` 接受公共 `x` 轴和多个 `{label, y}` 场景。给定场景的数值由调用方预先计算，滑块在场景间切换。
- `map` 接受 `{lon, lat, label}` 点位。底图采用等距经纬度布局，包含世界陆地轮廓和点位。底图数据来自 [Natural Earth 公共领域数据](https://www.naturalearthdata.com/downloads/110m-physical-vectors/110m-land/)。

## 模板

```powershell
.\.venv\Scripts\python.exe portable.py template create examples/template.json demo/templates
.\.venv\Scripts\python.exe portable.py template render demo/templates/weekly-brief examples/values.json demo/brief.md
.\.venv\Scripts\python.exe portable.py template revise examples/template-revise.json demo/templates
.\.venv\Scripts\python.exe portable.py template list demo/templates
```

模板输出含 `SKILL.md`、源文件快照和 `references/plan.json`。把生成的目录导入支持 Skills 的 agent 即可重复使用。TXT、Markdown 和 HTML 中的 `{{name}}` 可以由内置命令直接填充。Office、图像和 Site 工程则由目标 agent 的编辑工具按生成的计划处理。

| `source.type` | 输入和权限 |
| --- | --- |
| `file` | 使用 `path` 指向工作区内的参考文件。包括本地 Office 文件、下载的 ImageGen 图片、粘贴成 TXT 的 Slack 消息和 Site 源码 ZIP。 |
| `google` | 使用 `url` 指向 Google Docs、Sheets、Slides 或对应的 Drive 文件。将有导出权限的 OAuth access token 放入 MCP 进程的 `GOOGLE_DRIVE_ACCESS_TOKEN` 环境变量。可用的读取 scope 通常为 `drive.readonly`。运行时通过 Drive API 导出 DOCX、XLSX 或 PPTX。 [Google Drive 导出文档](https://developers.google.com/workspace/drive/api/reference/rest/v3/files/export) |
| `slack` | 使用 `url` 指向一条消息的 permalink。将已获该会话读取权限的 token 放入 `SLACK_ACCESS_TOKEN` 环境变量。频道或私信类型决定所需的历史读取 scope。带 `thread_ts` 的链接可定位回复。输出为该条消息的原始文本。 [Slack 消息历史](https://docs.slack.dev/reference/methods/conversations.history/) · [Slack 线程回复](https://docs.slack.dev/reference/methods/conversations.replies/) |
| `image` | 使用 `url` 指向可直接读取的 HTTPS PNG、JPEG 或 WebP，或用 `file` 读取已下载的图片。 |
| `site` | 使用 `url` 指向直接可访问的 HTTPS 页面。它保存当前 HTML 响应。带源码和资源的完整可移植工程请提供 ZIP。 |

远程来源需要一个直接链接。API 凭据从进程环境变量读取，生成的模板保留参考内容和来源信息。这个包使用已授权的 token，登录和 token 刷新由用户的 OAuth 流程或 agent 负责。

## 功能范围

- Word 修订和文字替换覆盖正文及表格中的连续文字。目标为页眉、文本框或表单控件时，需要相应的编辑工具。
- 表格文件的独立编辑覆盖 XLSX、CSV 和 TSV。旧版 XLS 可使用 `convert_legacy` 经 LibreOffice 转成 XLSX。
- 实时 Excel 使用 Windows COM。协同创作、加载项面板和云端文档会话由各自平台提供。
- 内嵌可视化遵循 MCP Apps 协议；浏览器 HTML 路径适用于只支持标准 MCP 工具的客户端。
- 模板库是本地目录。Site URL 来源保存 HTML 响应，导入完整工程时使用包含资源的源码 ZIP。
