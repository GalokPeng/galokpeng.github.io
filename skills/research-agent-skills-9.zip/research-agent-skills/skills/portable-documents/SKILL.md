---
name: portable-documents
description: Create, inspect or review a Word DOCX file using a standalone tool. Use for local Word authoring, targeted text edits, Word comments and tracked replacements.
---

# Portable Word review

Use `word_document` or `portable.py word SPEC.json`. Supported actions are `create`, `inspect`, `replace`, `track` and `comment`. Read the package command reference for the spec and examples. Use a new output path for reviewed documents. Text matches are case-sensitive and can span adjacent formatted text runs in a body paragraph or table cell. Use `office_export_pdf` when a local LibreOffice render is available.
