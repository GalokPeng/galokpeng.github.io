---
name: portable-template-creator
description: Build a reusable Agent Skill from a user-provided reference and instructions for what to keep, change, and supply on future runs. Supports local files, Google Workspace links, Slack permalinks, image URLs and published site HTML.
---

# Portable template creation

Call `template_create` with a template name, triggering description, source and the user's keep, change and inputs lists. The output directory contains a skill and its local reference snapshot. See the package README for authorization and source formats. Use a local export for inaccessible sources.

Use `template_render` for TXT, Markdown or HTML references with exact `{{slot_name}}` placeholders. For Office files, images and Site archives, apply the generated instructions using the agent host's editing tools. Use the CLI `portable.py template --help` when MCP tools are unavailable.

Use `template_catalog` to discover previously created templates under the selected local folder. Use `template_revise` with an existing template and a new name to keep a separate revision of its source or plan.
