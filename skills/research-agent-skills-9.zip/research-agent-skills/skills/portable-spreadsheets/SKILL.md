---
name: portable-spreadsheets
description: Work on standalone XLSX, CSV or TSV files using a local spreadsheet tool. Use to build, inspect, export, format and chart workbook data.
---

# Portable workbook files

Use `spreadsheet_workbook` or `portable.py spreadsheet SPEC.json`. For inspection specify the input, sheet, and a bounded A1 range. Workbook formulas are stored as formula text, and reading cached values requires an existing cache from a spreadsheet engine. Use the separate live Excel tool to recalculate in Windows Excel when the user needs that engine. Delimited-file import treats fields as text.
