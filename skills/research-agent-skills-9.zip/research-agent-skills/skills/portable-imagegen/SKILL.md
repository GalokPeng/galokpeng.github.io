---
name: portable-imagegen
description: Generate or edit PNG images using the OpenAI Images API from an agent with MCP or shell access, with an API credential configured in the environment.
---

# Portable image generation

Use `image_generate_edit` or `portable.py image SPEC.json`. A generation needs an image prompt and a new PNG output path. An edit also takes a list of authorized local reference images and may include a mask. Use supported options for the selected image model. The adapter reads `OPENAI_API_KEY` from its process environment.
