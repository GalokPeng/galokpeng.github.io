---
name: portable-windows
description: Inspect and operate a Windows desktop application through the portable MCP or CLI tools. Use for window screenshots, UI Automation trees, clicks, shortcuts and text entry in a user's Windows session.
---

# Portable Windows control

Use `desktop_windows` to find the intended window handle. Inspect the selected window with `desktop_capture` or `desktop_tree`. Click coordinates are physical pixels measured from the upper-left corner of the window. Tree rectangles use screen coordinates. Inspect the result when an action may change the active window, dialog, or input field. Resolve the handle of a new window via a fresh window list.

Use the registered MCP tools when available. If the agent can run commands, the portable package also ships `portable.py desktop --help`. The runtime runs in the signed-in Windows desktop session. See the package README for setup and platform limits.

Windows Graphics Capture is an optional screenshot backend when its dependency is installed. Honor the returned `click_offset` for screenshot-relative coordinates. Use the UI Automation rectangles to locate controls when the screenshot source cannot be aligned reliably.
