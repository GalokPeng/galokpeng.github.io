---
name: portable-visualize
description: Generate an interactive chart, scenario slider, or world point map as standalone HTML for browsers or an agent host that supports HTML previews.
---

# Portable visualizations

Call `visualize_build` with a specification and a new `.html` output path. From a shell use `portable.py visualize SPEC.json OUTPUT.html`. The package includes example specifications in `examples/`.

In a client that implements MCP Apps, call `visualize_inline` when an embedded chart is requested. The server advertises the UI resource through the tool metadata.

For line, bar and scatter charts, provide a title and one or more series with matching x and y arrays. For simulations, calculate the outcomes beforehand and provide a common x array plus named scenarios. For maps, provide lon, lat and label for each point. Open the generated HTML in a browser or offer it as a downloadable file. Use an agent host's HTML preview only when the host supports it.
