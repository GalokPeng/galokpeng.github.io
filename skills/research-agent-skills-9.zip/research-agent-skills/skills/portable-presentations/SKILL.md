---
name: portable-presentations
description: Create or inspect PPTX slides with charts and notes, or replace text in an existing presentation using a standalone tool.
---

# Portable presentations

Use `powerpoint` or `portable.py presentation SPEC.json` for `create`, `inspect` and `replace`. The create action can append to a specified PPTX theme deck. Use a title-and-content layout for slides with bullets. Verify layout through LibreOffice using `office_export_pdf` when it is available. For native Google Slides use the authorized Google bridge and its explicit input specification.
