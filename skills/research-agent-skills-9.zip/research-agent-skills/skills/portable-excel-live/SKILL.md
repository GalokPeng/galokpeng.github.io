---
name: portable-excel-live
description: Read, write, format, chart, calculate, save or export a sheet in an explicitly selected open Windows Excel workbook through the standalone COM adapter.
---

# Portable live Excel

Use `live_excel` or `portable.py excel-live SPEC.json`. Discover the open workbook and sheet names using `list`. Send the exact name and A1 rectangle for range operations. A write changes the open workbook immediately. Use `save` when saving to its existing location is requested. The adapter attaches to a registered Windows desktop Excel session.
