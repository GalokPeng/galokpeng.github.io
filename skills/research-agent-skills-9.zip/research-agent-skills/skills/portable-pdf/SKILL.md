---
name: portable-pdf
description: Create, inspect, render, join, select pages from, or fill existing PDF forms using a standalone local PDF tool.
---

# Portable PDF

Use `pdf_document` or `portable.py pdf SPEC.json`. Page numbers are one-based. Select specific pages when extracting a large document. Use `render` to inspect layout or graphics and `inspect` to list AcroForm field names before using `fill`. Choose a new output file for operations that write a document. For a scanned PDF, use `ocr` with installed Tesseract and the appropriate language pack.
